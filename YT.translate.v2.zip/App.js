import React, { useState } from 'react';
import { View, Text, TextInput, Button, ActivityIndicator, ScrollView } from 'react-native';
import * as Speech from 'expo-speech';

const YT_API = 'https://youtube-transcript-api.up.railway.app/transcript?url=';
const TRANSLATE_API = 'https://api.mymemory.translated.net/get?q=';

export default function App() {
  const [url, setUrl] = useState('');
  const [translated, setTranslated] = useState([]);
  const [loading, setLoading] = useState(false);

  const getTranscript = async () => {
    setLoading(true);
    setTranslated([]);
    try {
      const res = await fetch(YT_API + encodeURIComponent(url));
      const json = await res.json();
      translateAndSpeak(json);
    } catch (err) {
      console.error('Transcript error:', err);
      setLoading(false);
    }
  };

  const translateAndSpeak = async (lines) => {
    const results = [];
    for (const line of lines) {
      try {
        const res = await fetch(
          TRANSLATE_API + encodeURIComponent(line.text) + '&langpair=en|ro'
        );
        const json = await res.json();
        const ro = json.responseData.translatedText;
        results.push({ original: line.text, ro });
        Speech.speak(ro, { language: 'ro-RO' });
        await new Promise((resolve) => setTimeout(resolve, 3000)); // pause
      } catch {
        results.push({ original: line.text, ro: '[Translation error]' });
      }
    }
    setTranslated(results);
    setLoading(false);
  };

  return (
    <ScrollView contentContainerStyle={{ padding: 20, paddingTop: 50 }}>
      <Text style={{ fontSize: 22, fontWeight: 'bold', marginBottom: 20 }}>
        YouTube Translate (EN → RO)
      </Text>
      <TextInput
        placeholder="Paste YouTube URL"
        value={url}
        onChangeText={setUrl}
        style={{ borderWidth: 1, padding: 10, marginBottom: 10 }}
      />
      <Button title="Translate & Speak" onPress={getTranscript} />
      {loading && <ActivityIndicator size="large" color="blue" style={{ marginTop: 20 }} />}
      {translated.map((line, i) => (
        <View key={i} style={{ marginTop: 15 }}>
          <Text>EN: {line.original}</Text>
          <Text style={{ color: 'green' }}>RO: {line.ro}</Text>
        </View>
      ))}
    </ScrollView>
  );
}
